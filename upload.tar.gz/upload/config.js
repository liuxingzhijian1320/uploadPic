module.exports = {
    port: 3092, // 端口
    secret: 'ilovehangforever',
    // connectionStr: 'mongodb://127.0.0.1:27017/zhihuAPI',
};